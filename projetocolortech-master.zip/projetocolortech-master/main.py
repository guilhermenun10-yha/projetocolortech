from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]

        if username == "admin" and password == "123456":
            return redirect(url_for("medidas"))
        else:
            return "<h3 style='color:red;'>Usuário ou senha incorretos!</h3>"
    return render_template("login.html")

@app.route("/medidas")
def medidas():
    return render_template("medidas.html")

@app.route("/salvar_medidas", methods=["POST"])
def salvar_medidas():
    altura = float(request.form["altura"])
    largura = float(request.form["largura"])
    quantidade = int(request.form["quantidade"])
    cor = request.form["cor"]

    # cálculo da área total em cm²
    area_total_cm2 = altura * largura * quantidade
    area_total_m2 = area_total_cm2 / 10000  # conversão para m²
    litros_necessarios = area_total_m2 * 0.35  # 0,35 L por m²

    # envia os dados para o orçamento
    return render_template(
        "orcamento.html",
        altura=altura,
        largura=largura,
        quantidade=quantidade,
        cor=cor,
        litros=litros_necessarios
    )

